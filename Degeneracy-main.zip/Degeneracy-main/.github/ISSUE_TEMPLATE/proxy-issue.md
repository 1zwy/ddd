---
name: Proxy Issue
about: Issues with Corrosion
title: Proxy Issue
labels: ''
assignees: ''

---

**Is this issue with Stealth Mode, Classic Mode, or both?**
